#!/usr/bin/env python3
"""
Invoice Reminder Automator
===========================

Reads a CSV file of invoices and generates ready-to-send reminder email
drafts (.txt files) for overdue or soon-due invoices. Three escalation
tiers are supported:

    1. Polite first reminder   -> due soon or just past due (1-7 days overdue)
    2. Firm second reminder    -> moderately overdue (8-21 days overdue)
    3. Final notice            -> severely overdue (22+ days overdue)

Usage:
    python invoice_reminder_automator.py invoices.csv
    python invoice_reminder_automator.py invoices.csv --output-dir output
    python invoice_reminder_automator.py invoices.csv --today 2024-06-01

Required CSV columns (header row):
    client_name, client_email, invoice_number, amount, due_date, status

- due_date format: YYYY-MM-DD
- status: e.g. "paid", "unpaid", "sent" (rows with status "paid" are skipped)

A sample "invoices.csv" is included in this directory for demo purposes.

No external dependencies required (Python standard library only).
"""

import argparse
import csv
import os
import re
import sys
from datetime import datetime, date

DATE_FORMAT = "%Y-%m-%d"

# Overdue-day thresholds for escalation tiers.
FIRST_REMINDER_MIN_DAYS = -7   # from 7 days before due date
SECOND_REMINDER_MIN_DAYS = 8   # 8-21 days overdue -> firm reminder
FINAL_NOTICE_MIN_DAYS = 22     # 22+ days overdue -> final notice

PAID_STATUSES = {"paid", "closed", "cancelled", "canceled"}


def slugify(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "_", value)
    return value.strip("_") or "client"


def parse_date(value: str) -> date:
    return datetime.strptime(value.strip(), DATE_FORMAT).date()


def classify_invoice(due_date: date, today: date):
    """Return one of: None, 'upcoming', 'first', 'second', 'final'."""
    days_overdue = (today - due_date).days

    if days_overdue < FIRST_REMINDER_MIN_DAYS:
        return None  # not due soon enough to bother yet
    if days_overdue < 0:
        return "upcoming"
    if days_overdue < SECOND_REMINDER_MIN_DAYS:
        return "first"
    if days_overdue < FINAL_NOTICE_MIN_DAYS:
        return "second"
    return "final"


def format_money(amount: str) -> str:
    try:
        return f"${float(amount):,.2f}"
    except (ValueError, TypeError):
        return str(amount)


def polite_first_reminder(row, days_overdue, today):
    client = row["client_name"]
    email = row["client_email"]
    invoice = row["invoice_number"]
    amount = format_money(row["amount"])
    due = row["due_date"]

    if days_overdue < 0:
        timing = f"is due on {due}"
    else:
        timing = f"was due on {due} and is now {days_overdue} day(s) past due"

    subject = f"Friendly Reminder: Invoice {invoice} {('Due Soon' if days_overdue < 0 else 'Past Due')}"

    body = f"""To: {email}
Subject: {subject}

Hi {client},

I hope you're doing well! This is a quick, friendly reminder that invoice
#{invoice} for {amount} {timing}.

If you've already sent payment, thank you — please disregard this note.
Otherwise, you can find the invoice details attached / in our previous
email, and we'd appreciate it if you could take care of it at your
earliest convenience.

Please let us know if you have any questions or if there's anything we
can help clarify.

Thanks so much,
Accounts Receivable
"""
    return body


def firm_second_reminder(row, days_overdue, today):
    client = row["client_name"]
    email = row["client_email"]
    invoice = row["invoice_number"]
    amount = format_money(row["amount"])
    due = row["due_date"]

    subject = f"Second Notice: Invoice {invoice} is {days_overdue} Days Overdue"

    body = f"""To: {email}
Subject: {subject}

Hi {client},

We wanted to follow up regarding invoice #{invoice} for {amount}, which
was due on {due} and is now {days_overdue} days overdue.

We understand things can slip through the cracks, but we'd appreciate
prompt payment as soon as possible. If there's an issue with the invoice
or a reason for the delay, please reach out so we can work it out
together.

Could you please confirm the expected payment date, or send payment
directly, within the next 5 business days?

Thank you for your attention to this matter.

Best regards,
Accounts Receivable
"""
    return body


def final_notice(row, days_overdue, today):
    client = row["client_name"]
    email = row["client_email"]
    invoice = row["invoice_number"]
    amount = format_money(row["amount"])
    due = row["due_date"]

    subject = f"FINAL NOTICE: Invoice {invoice} — {days_overdue} Days Overdue"

    body = f"""To: {email}
Subject: {subject}

Hi {client},

This is a final notice regarding invoice #{invoice} for {amount}, originally
due on {due}. The payment is now {days_overdue} days overdue, and despite
previous reminders, we have not yet received payment or a response.

Please remit payment in full within 7 days of this notice. If payment is
not received or arrangements are not made by then, we may need to pause
further work and explore additional collection options, which we would
prefer to avoid.

If there are extenuating circumstances or you believe this invoice is in
error, please contact us immediately so we can resolve this together.

Regards,
Accounts Receivable
"""
    return body


def upcoming_reminder(row, days_until_due, today):
    client = row["client_name"]
    email = row["client_email"]
    invoice = row["invoice_number"]
    amount = format_money(row["amount"])
    due = row["due_date"]

    subject = f"Upcoming Payment Reminder: Invoice {invoice} Due {due}"

    body = f"""To: {email}
Subject: {subject}

Hi {client},

Just a friendly heads-up that invoice #{invoice} for {amount} is due on
{due} (in {days_until_due} day(s)).

No action needed if payment is already scheduled — thank you! Otherwise,
please let us know if you have any questions about the invoice.

Thanks,
Accounts Receivable
"""
    return body


TIER_LABELS = {
    "upcoming": "upcoming_reminder",
    "first": "first_reminder",
    "second": "second_reminder",
    "final": "final_notice",
}


def process_invoices(csv_path: str, output_dir: str, today: date) -> None:
    if not os.path.isfile(csv_path):
        print(f"Error: CSV file not found: {csv_path}", file=sys.stderr)
        sys.exit(1)

    os.makedirs(output_dir, exist_ok=True)

    required_cols = {"client_name", "client_email", "invoice_number", "amount", "due_date", "status"}

    summary = {"upcoming": 0, "first": 0, "second": 0, "final": 0, "skipped_paid": 0, "errors": 0}

    with open(csv_path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        fieldnames = {fn.strip().lower() for fn in (reader.fieldnames or [])}
        missing = required_cols - fieldnames
        if missing:
            print(f"Error: CSV missing required columns: {', '.join(sorted(missing))}", file=sys.stderr)
            sys.exit(1)

        for i, raw_row in enumerate(reader, start=2):  # start=2 accounts for header line
            row = {k.strip().lower(): (v or "").strip() for k, v in raw_row.items()}

            if row.get("status", "").lower() in PAID_STATUSES:
                summary["skipped_paid"] += 1
                continue

            try:
                due = parse_date(row["due_date"])
            except ValueError:
                print(f"[WARN] Row {i}: invalid due_date '{row.get('due_date')}', skipping.", file=sys.stderr)
                summary["errors"] += 1
                continue

            tier = classify_invoice(due, today)
            if tier is None:
                continue

            days_overdue = (today - due).days
            client_slug = slugify(row.get("client_name", "client"))
            invoice_no = row.get("invoice_number", "unknown").strip() or "unknown"
            label = TIER_LABELS[tier]
            filename = f"{client_slug}_invoice_{invoice_no}_{label}.txt"
            filepath = os.path.join(output_dir, filename)

            if tier == "upcoming":
                content = upcoming_reminder(row, abs(days_overdue), today)
            elif tier == "first":
                content = polite_first_reminder(row, max(days_overdue, 0), today)
            elif tier == "second":
                content = firm_second_reminder(row, days_overdue, today)
            else:
                content = final_notice(row, days_overdue, today)

            with open(filepath, "w", encoding="utf-8") as out:
                out.write(content)

            summary[tier] += 1
            print(f"[{label.upper():>18}] {row.get('client_name')} - Invoice {invoice_no} -> {filepath}")

    print("\n--- Summary ---")
    print(f"Upcoming reminders generated: {summary['upcoming']}")
    print(f"First reminders generated:    {summary['first']}")
    print(f"Second reminders generated:   {summary['second']}")
    print(f"Final notices generated:      {summary['final']}")
    print(f"Skipped (already paid):       {summary['skipped_paid']}")
    if summary["errors"]:
        print(f"Rows with errors:             {summary['errors']}")
    print(f"\nAll reminder drafts saved to: {os.path.abspath(output_dir)}")


def parse_args():
    parser = argparse.ArgumentParser(
        description="Generate invoice reminder email drafts (polite, firm, final) from a CSV of invoices."
    )
    parser.add_argument("csv_file", help="Path to invoices CSV file")
    parser.add_argument("--output-dir", default="output", help="Directory to save reminder drafts (default: ./output)")
    parser.add_argument(
        "--today",
        default=None,
        help="Override 'today' date for testing/demo purposes (format YYYY-MM-DD). Defaults to current date.",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    today = parse_date(args.today) if args.today else date.today()
    process_invoices(args.csv_file, args.output_dir, today)


if __name__ == "__main__":
    main()
