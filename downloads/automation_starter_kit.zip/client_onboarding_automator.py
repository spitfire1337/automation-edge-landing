#!/usr/bin/env python3
"""
Client Onboarding Automator
============================

Automates the busywork of onboarding a new client:
  1. Generates a personalized welcome email draft (.txt)
  2. Creates a standardized project folder structure
  3. Generates an onboarding checklist (Markdown)

Usage (single client via CLI args):
    python client_onboarding_automator.py --name "Jane Doe" --email "jane@acme.com" \
        --company "Acme Inc" --project "Website Redesign"

Usage (batch via CSV file):
    python client_onboarding_automator.py --csv clients.csv

CSV file must have header row with columns:
    name,email,company,project

All generated files/folders are placed under ./clients/<client_folder_name>/
by default. Use --output-dir to change the base output location.

No external dependencies required (Python standard library only).
"""

import argparse
import csv
import os
import re
import sys
from datetime import datetime, timedelta


DEFAULT_SUBFOLDERS = [
    "01_Contracts",
    "02_Assets_Received",
    "03_Work_In_Progress",
    "04_Deliverables",
    "05_Invoices",
    "06_Communication",
]


def slugify(value: str) -> str:
    """Turn a string into a filesystem-friendly slug."""
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "_", value)
    return value.strip("_") or "client"


def build_client_folder_name(name: str, company: str) -> str:
    base = company if company else name
    return slugify(base)


def create_project_folders(base_path: str, subfolders=None) -> list:
    subfolders = subfolders or DEFAULT_SUBFOLDERS
    created = []
    os.makedirs(base_path, exist_ok=True)
    for folder in subfolders:
        folder_path = os.path.join(base_path, folder)
        os.makedirs(folder_path, exist_ok=True)
        created.append(folder_path)
    return created


def generate_welcome_email(name: str, email: str, company: str, project: str) -> str:
    """Return the text content of a personalized welcome email draft."""
    today = datetime.now().strftime("%B %d, %Y")
    company_line = f" at {company}" if company else ""
    project_line = project if project else "your project"

    email_text = f"""To: {email}
Subject: Welcome Aboard, {name}! Let's Get Started on {project_line}

Date: {today}

Hi {name},

Thank you for choosing to work with us{company_line}! We're excited to get
started on "{project_line}" and want to make sure the kickoff process is as
smooth as possible.

Here's what happens next:

1. Review & sign the attached project agreement (if not already done).
2. Complete the onboarding checklist we've included so we can gather
   everything needed to hit the ground running.
3. Share any brand assets, credentials, or reference materials you'd like
   us to use — you can upload them or reply directly to this email.
4. We'll schedule a kickoff call within the next few business days to align
   on goals, timeline, and expectations.

If you have any questions in the meantime, just reply to this email or
reach out to your point of contact directly.

We're looking forward to a great working relationship!

Best regards,
Your Project Team
"""
    return email_text


def generate_onboarding_checklist(name: str, company: str, project: str) -> str:
    today = datetime.now().strftime("%Y-%m-%d")
    kickoff_deadline = (datetime.now() + timedelta(days=7)).strftime("%Y-%m-%d")

    checklist = f"""# Onboarding Checklist — {name}{f" ({company})" if company else ""}

**Project:** {project or "N/A"}
**Created:** {today}
**Target kickoff date:** {kickoff_deadline}

## Client Setup
- [ ] Signed contract / agreement received
- [ ] Client added to CRM / project management tool
- [ ] Invoicing details confirmed (billing name, address, payment method)
- [ ] Primary point of contact confirmed (name, email, phone)

## Information Gathering
- [ ] Project goals & success criteria documented
- [ ] Brand assets received (logo, style guide, fonts, colors)
- [ ] Access/credentials received (if applicable): website, hosting, domain, socials
- [ ] Reference materials / competitor examples collected

## Communication
- [ ] Welcome email sent
- [ ] Kickoff call scheduled
- [ ] Preferred communication channel agreed (email, Slack, etc.)
- [ ] Reporting/update cadence agreed (weekly, biweekly, etc.)

## Internal Setup
- [ ] Project folder structure created
- [ ] Team members assigned
- [ ] Timeline / milestones drafted
- [ ] First invoice / deposit scheduled

## Kickoff
- [ ] Kickoff call completed
- [ ] Action items from kickoff call documented
- [ ] Project officially started

---
*Generated automatically by Client Onboarding Automator.*
"""
    return checklist


def onboard_client(name: str, email: str, company: str, project: str, output_dir: str) -> str:
    """Run the full onboarding automation for a single client. Returns the client folder path."""
    folder_name = build_client_folder_name(name, company)
    client_base = os.path.join(output_dir, folder_name)

    create_project_folders(client_base)

    welcome_email = generate_welcome_email(name, email, company, project)
    email_path = os.path.join(client_base, "welcome_email_draft.txt")
    with open(email_path, "w", encoding="utf-8") as f:
        f.write(welcome_email)

    checklist = generate_onboarding_checklist(name, company, project)
    checklist_path = os.path.join(client_base, "onboarding_checklist.md")
    with open(checklist_path, "w", encoding="utf-8") as f:
        f.write(checklist)

    print(f"[OK] Onboarded '{name}' -> {client_base}")
    print(f"     - {email_path}")
    print(f"     - {checklist_path}")
    for sub in DEFAULT_SUBFOLDERS:
        print(f"     - {os.path.join(client_base, sub)}/")

    return client_base


def onboard_from_csv(csv_path: str, output_dir: str) -> None:
    if not os.path.isfile(csv_path):
        print(f"Error: CSV file not found: {csv_path}", file=sys.stderr)
        sys.exit(1)

    with open(csv_path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        required = {"name", "email", "company", "project"}
        fieldnames = {fn.strip().lower() for fn in (reader.fieldnames or [])}
        missing = required - fieldnames
        if missing:
            print(f"Error: CSV missing required columns: {', '.join(sorted(missing))}", file=sys.stderr)
            sys.exit(1)

        count = 0
        for row in reader:
            normalized = {k.strip().lower(): (v or "").strip() for k, v in row.items()}
            if not normalized.get("name"):
                continue
            onboard_client(
                normalized.get("name", ""),
                normalized.get("email", ""),
                normalized.get("company", ""),
                normalized.get("project", ""),
                output_dir,
            )
            count += 1

    print(f"\nDone. Onboarded {count} client(s) from {csv_path}.")


def parse_args():
    parser = argparse.ArgumentParser(
        description="Automate new client onboarding: welcome email, project folders, and checklist."
    )
    parser.add_argument("--name", help="Client's full name")
    parser.add_argument("--email", help="Client's email address")
    parser.add_argument("--company", default="", help="Client's company name (optional)")
    parser.add_argument("--project", default="", help="Project type / name (optional)")
    parser.add_argument("--csv", help="Path to a CSV file with columns: name,email,company,project")
    parser.add_argument(
        "--output-dir",
        default="clients",
        help="Base directory where client folders will be created (default: ./clients)",
    )
    return parser.parse_args()


def main():
    args = parse_args()

    if not args.csv and not args.name:
        print("Error: provide either --name (with --email/--company/--project) or --csv <file>", file=sys.stderr)
        sys.exit(1)

    os.makedirs(args.output_dir, exist_ok=True)

    if args.csv:
        onboard_from_csv(args.csv, args.output_dir)
    else:
        if not args.email:
            print("Error: --email is required when using --name", file=sys.stderr)
            sys.exit(1)
        onboard_client(args.name, args.email, args.company, args.project, args.output_dir)


if __name__ == "__main__":
    main()
