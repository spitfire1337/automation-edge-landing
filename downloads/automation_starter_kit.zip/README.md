# Automation Starter Kit

A collection of three self-contained Python CLI scripts to automate common
freelance / small-business admin tasks:

1. **Client Onboarding Automator** — welcome emails, project folders, and an
   onboarding checklist for every new client.
2. **Invoice Reminder Automator** — auto-generated, ready-to-send invoice
   reminder emails (polite, firm, final notice) based on due dates.
3. **Data Cleanup Toolkit** — clean messy CSV data (contacts, leads, client
   lists) in one command.

All three scripts use **only the Python standard library** — no external
packages, no API keys, no signup required. Just install Python and run.

---

## Requirements

- Python 3.7 or later
- No `pip install` needed (standard library only)

Verify your Python version:

```bash
python3 --version
```

---

## 1. Client Onboarding Automator

**File:** `client_onboarding_automator.py`

Automates new-client setup:

- Generates a personalized **welcome email draft** (`.txt`)
- Creates a **standardized project folder structure**
  (`01_Contracts`, `02_Assets_Received`, `03_Work_In_Progress`,
  `04_Deliverables`, `05_Invoices`, `06_Communication`)
- Generates an **onboarding checklist** (`.md`) with due dates

### Usage — single client via CLI args

```bash
python client_onboarding_automator.py \
  --name "Jane Doe" \
  --email "jane@acme.com" \
  --company "Acme Inc" \
  --project "Website Redesign"
```

Output goes to `./clients/acme_inc/` by default. Use `--output-dir` to change
the destination.

### Usage — batch via CSV

Create a CSV with columns `name,email,company,project`, then run:

```bash
python client_onboarding_automator.py --csv clients.csv
```

Each row generates its own client folder with a welcome email and checklist.

---

## 2. Invoice Reminder Automator

**File:** `invoice_reminder_automator.py`
**Sample data included:** `invoices.csv`

Reads a CSV of invoices and generates escalating reminder email drafts:

| Tier              | Trigger                              |
|-------------------|----------------------------------------|
| Upcoming reminder | Due within the next 7 days             |
| First reminder    | 0–7 days overdue (polite)               |
| Second reminder   | 8–21 days overdue (firm)                |
| Final notice      | 22+ days overdue                        |

Invoices with `status` of `paid`/`closed`/`cancelled` are automatically
skipped.

### CSV format required

```
client_name,client_email,invoice_number,amount,due_date,status
```

`due_date` must be `YYYY-MM-DD`.

### Usage

```bash
python invoice_reminder_automator.py invoices.csv
python invoice_reminder_automator.py invoices.csv --output-dir output
```

Reminder drafts are written to `./output/` (or your `--output-dir`) as
individual `.txt` files, one per invoice, e.g.
`acme_inc_invoice_INV-1004_final_notice.txt`. Each file is formatted as a
ready-to-paste email with a `To:` and `Subject:` line.

Use `--today YYYY-MM-DD` to override "today's" date — handy for testing or
demoing the sample `invoices.csv` against a fixed reference date.

---

## 3. Data Cleanup Toolkit

**File:** `data_cleanup_toolkit.py`
**Sample data included:** `sample_contacts.csv`

Cleans a CSV file of contacts/leads/clients:

- Removes exact **duplicate rows**
- **Trims whitespace** from every cell
- Standardizes **phone numbers** to `(XXX) XXX-XXXX` format (10-digit
  US/Canada numbers; other formats are digit-stripped as a best effort)
- Standardizes **email addresses** to lowercase
- Flags (or optionally fills) **missing required fields**
- Writes a cleaned CSV plus a `cleanup_report.txt` summary

Email and phone columns are auto-detected by column name (any column
containing "email" or "phone", case-insensitive).

### Usage

```bash
python data_cleanup_toolkit.py input.csv output.csv
```

With required-field checks (comma-separated column names):

```bash
python data_cleanup_toolkit.py sample_contacts.csv cleaned_contacts.csv --required-fields name,email
```

Fill missing values instead of flagging them:

```bash
python data_cleanup_toolkit.py sample_contacts.csv cleaned_contacts.csv --required-fields name,email --fill-missing "N/A"
```

Custom report location:

```bash
python data_cleanup_toolkit.py input.csv output.csv --report my_report.txt
```

It can also be imported as a library:

```python
from data_cleanup_toolkit import clean_csv
clean_csv("input.csv", "output.csv", required_fields=["name", "email"])
```

---

## Quick Demo (try it now)

```bash
cd automation_starter_kit

# 1. Onboard a demo client
python client_onboarding_automator.py --name "Demo Client" --email "demo@example.com" --company "Demo Co" --project "Brand Refresh"

# 2. Generate invoice reminders from the included sample data
python invoice_reminder_automator.py invoices.csv --output-dir output

# 3. Clean the included sample contacts
python data_cleanup_toolkit.py sample_contacts.csv cleaned_contacts.csv --required-fields name,email
```

Check the newly created `clients/`, `output/`, `cleaned_contacts.csv`, and
`cleanup_report.txt` to see the results.

---

## Notes

- All scripts are self-contained single files — copy them anywhere and run.
- Generated emails are **drafts only**; review and send manually via your
  own email client, or adapt the scripts to integrate with an email API.
- No data is sent anywhere — everything runs 100% locally on your machine.
