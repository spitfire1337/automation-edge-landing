#!/usr/bin/env python3
"""
Data Cleanup Toolkit
======================

A CLI script and reusable library for common CSV data-cleaning tasks:

  - Removes exact duplicate rows
  - Trims leading/trailing whitespace from all fields
  - Standardizes phone numbers to a consistent format: (XXX) XXX-XXXX
    (10-digit US/Canada numbers; other lengths are left cleaned but unformatted)
  - Standardizes email addresses to lowercase
  - Flags (or optionally fills) missing values in required fields
  - Writes a cleaned CSV file
  - Writes a cleanup_report.txt summarizing every change made

Usage:
    python data_cleanup_toolkit.py input.csv output.csv
    python data_cleanup_toolkit.py input.csv output.csv --required-fields name,email
    python data_cleanup_toolkit.py input.csv output.csv --fill-missing "N/A"
    python data_cleanup_toolkit.py input.csv output.csv --report custom_report.txt

Column detection is automatic and case-insensitive:
  - Any column named/containing "email" is treated as an email column.
  - Any column named/containing "phone" is treated as a phone column.

Can also be imported and used as a library:
    from data_cleanup_toolkit import clean_csv
    clean_csv("input.csv", "output.csv")

No external dependencies required (Python standard library only).
"""

import argparse
import csv
import os
import re
import sys
from collections import OrderedDict


def is_email_column(col_name: str) -> bool:
    return "email" in col_name.lower()


def is_phone_column(col_name: str) -> bool:
    return "phone" in col_name.lower()


def trim_value(value: str) -> str:
    if value is None:
        return value
    return value.strip()


def standardize_email(value: str) -> str:
    if not value:
        return value
    return value.strip().lower()


def standardize_phone(value: str) -> str:
    """Standardize to (XXX) XXX-XXXX for 10-digit numbers; 11-digit numbers
    with a leading '1' are also handled. Other lengths are returned with
    just non-digit characters stripped (best-effort)."""
    if not value:
        return value
    digits = re.sub(r"\D", "", value)

    if len(digits) == 11 and digits.startswith("1"):
        digits = digits[1:]

    if len(digits) == 10:
        return f"({digits[0:3]}) {digits[3:6]}-{digits[6:10]}"

    # Fallback: return the digits-only version if we can't confidently format it.
    return digits if digits else value


def clean_csv(input_path: str, output_path: str, required_fields=None, fill_missing=None, report_path=None):
    """Clean a CSV file and write the results. Returns a report dict."""
    if not os.path.isfile(input_path):
        raise FileNotFoundError(f"Input CSV not found: {input_path}")

    required_fields = required_fields or []
    required_fields_lower = [f.strip().lower() for f in required_fields if f.strip()]

    with open(input_path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames or []
        rows = list(reader)

    original_row_count = len(rows)

    # --- Trim whitespace on every field ---
    trimmed_cells = 0
    for row in rows:
        for key, value in row.items():
            new_value = trim_value(value)
            if new_value != value:
                trimmed_cells += 1
            row[key] = new_value

    # --- Standardize emails and phone numbers ---
    email_cols = [col for col in fieldnames if is_email_column(col)]
    phone_cols = [col for col in fieldnames if is_phone_column(col)]

    emails_standardized = 0
    phones_standardized = 0

    for row in rows:
        for col in email_cols:
            original = row.get(col, "")
            standardized = standardize_email(original)
            if standardized != original:
                emails_standardized += 1
            row[col] = standardized

        for col in phone_cols:
            original = row.get(col, "")
            standardized = standardize_phone(original)
            if standardized != original:
                phones_standardized += 1
            row[col] = standardized

    # --- Remove exact duplicate rows (based on all column values) ---
    seen = OrderedDict()
    duplicates_removed = 0
    deduped_rows = []
    for row in rows:
        key = tuple(row.get(col, "") for col in fieldnames)
        if key in seen:
            duplicates_removed += 1
            continue
        seen[key] = True
        deduped_rows.append(row)
    rows = deduped_rows

    # --- Missing required fields: flag or fill ---
    missing_field_counts = {field: 0 for field in required_fields_lower}
    flagged_rows = []
    field_lookup = {col.lower(): col for col in fieldnames}

    if "_issues" not in fieldnames and required_fields_lower:
        fieldnames = list(fieldnames) + ["_issues"]

    for idx, row in enumerate(rows, start=2):  # +2 to account for header row & 1-index
        issues = []
        for req_field_lower in required_fields_lower:
            actual_col = field_lookup.get(req_field_lower)
            if actual_col is None:
                continue  # required field isn't even a column; skip
            value = row.get(actual_col, "")
            if not value:
                missing_field_counts[req_field_lower] += 1
                if fill_missing is not None:
                    row[actual_col] = fill_missing
                else:
                    issues.append(actual_col)
        if issues:
            row["_issues"] = f"Missing: {', '.join(issues)}"
            flagged_rows.append((idx, issues))
        elif "_issues" in fieldnames:
            row.setdefault("_issues", "")

    # --- Write cleaned CSV ---
    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({col: row.get(col, "") for col in fieldnames})

    # --- Build report ---
    report_lines = []
    report_lines.append("Data Cleanup Toolkit — Cleanup Report")
    report_lines.append("=" * 42)
    report_lines.append(f"Input file:  {input_path}")
    report_lines.append(f"Output file: {output_path}")
    report_lines.append("")
    report_lines.append(f"Original row count:      {original_row_count}")
    report_lines.append(f"Duplicate rows removed:  {duplicates_removed}")
    report_lines.append(f"Final row count:         {len(rows)}")
    report_lines.append("")
    report_lines.append(f"Cells trimmed of whitespace: {trimmed_cells}")
    report_lines.append(f"Email values standardized (lowercased): {emails_standardized} (columns: {', '.join(email_cols) or 'none detected'})")
    report_lines.append(f"Phone values standardized (formatted):  {phones_standardized} (columns: {', '.join(phone_cols) or 'none detected'})")
    report_lines.append("")

    if required_fields_lower:
        report_lines.append("Required field checks:")
        for field in required_fields_lower:
            actual_col = field_lookup.get(field, f"{field} (column not found)")
            count = missing_field_counts.get(field, 0)
            report_lines.append(f"  - {actual_col}: {count} missing value(s)")
        if fill_missing is not None:
            report_lines.append(f"\nMissing values were filled with: '{fill_missing}'")
        else:
            report_lines.append(f"\nRows with missing required fields were flagged in the '_issues' column ({len(flagged_rows)} row(s) flagged).")
    else:
        report_lines.append("No required fields specified; missing-value checks skipped.")

    report_lines.append("")
    report_lines.append("Done.")

    report_text = "\n".join(report_lines)

    if report_path:
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(report_text + "\n")

    return {
        "report_text": report_text,
        "original_row_count": original_row_count,
        "final_row_count": len(rows),
        "duplicates_removed": duplicates_removed,
        "trimmed_cells": trimmed_cells,
        "emails_standardized": emails_standardized,
        "phones_standardized": phones_standardized,
        "missing_field_counts": missing_field_counts,
        "flagged_rows": flagged_rows,
    }


def parse_args():
    parser = argparse.ArgumentParser(
        description="Clean a CSV file: remove duplicates, trim whitespace, standardize emails/phones, flag missing fields."
    )
    parser.add_argument("input_csv", help="Path to the input CSV file")
    parser.add_argument("output_csv", help="Path to write the cleaned CSV file")
    parser.add_argument(
        "--required-fields",
        default="",
        help="Comma-separated list of column names that are required (e.g. 'name,email')",
    )
    parser.add_argument(
        "--fill-missing",
        default=None,
        help="If set, missing required fields are filled with this value instead of being flagged.",
    )
    parser.add_argument(
        "--report",
        default=None,
        help="Path for the cleanup report (default: cleanup_report.txt next to the output CSV)",
    )
    return parser.parse_args()


def main():
    args = parse_args()

    required_fields = [f.strip() for f in args.required_fields.split(",") if f.strip()]

    report_path = args.report
    if not report_path:
        output_dir = os.path.dirname(os.path.abspath(args.output_csv))
        report_path = os.path.join(output_dir, "cleanup_report.txt")

    try:
        result = clean_csv(
            args.input_csv,
            args.output_csv,
            required_fields=required_fields,
            fill_missing=args.fill_missing,
            report_path=report_path,
        )
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    print(result["report_text"])
    print(f"\nCleaned CSV saved to: {os.path.abspath(args.output_csv)}")
    print(f"Report saved to:      {os.path.abspath(report_path)}")


if __name__ == "__main__":
    main()
