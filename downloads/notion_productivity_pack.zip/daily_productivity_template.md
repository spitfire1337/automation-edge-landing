# Daily Productivity Planner

**Date:** _____________

## 🎯 Top 3 Priorities
Focus on no more than three high-impact tasks today.

1. [ ] Priority 1: ___________________________________
2. [ ] Priority 2: ___________________________________
3. [ ] Priority 3: ___________________________________

## ⏰ Time Blocks

| Time | Activity | Notes |
|------|----------|-------|
| 7:00 – 8:00 | | |
| 8:00 – 9:00 | | |
| 9:00 – 10:00 | | |
| 10:00 – 11:00 | | |
| 11:00 – 12:00 | | |
| 12:00 – 1:00 | Lunch / Break | |
| 1:00 – 2:00 | | |
| 2:00 – 3:00 | | |
| 3:00 – 4:00 | | |
| 4:00 – 5:00 | | |
| 5:00 – 6:00 | Wrap-up / Review | |

## 📝 Notes
- ___________________________________
- ___________________________________
- ___________________________________

## ✅ End of Day Review
- **What went well today?**
  ___________________________________
- **What could be improved?**
  ___________________________________
- **Did I complete my Top 3 Priorities?** Yes / No / Partially
- **What's the #1 priority for tomorrow?**
  ___________________________________

---
*Tip: Duplicate this page each morning, or turn it into a Notion template button so a fresh copy is created automatically with one click.*
