# Setup Guide: Importing the Notion Productivity Pack

Follow these steps to turn the included CSV and Markdown files into a fully working Notion workspace in about 10 minutes.

## Step 1: Create a Home Page

1. In Notion, click **+ New page** in your sidebar.
2. Name it something like "🧠 Productivity Pack" — this will be the parent page holding all imported content.

## Step 2: Import the CSV Databases

Repeat for each of the three CSV files (`client_crm_tracker.csv`, `task_dashboard.csv`, `project_tracker.csv`):

1. Inside your "Productivity Pack" page, click **Import** at the bottom of the sidebar menu (or use `Ctrl/Cmd + P` → "Import").
2. Choose **CSV**.
3. Select the file from your computer.
4. Notion will automatically create it as a database (table) with columns matching the CSV headers.
5. Rename the resulting page to something clean, e.g. "Client CRM Tracker."

**Recommended column type adjustments after import** (Notion imports everything as text by default):

| Database | Column | Suggested Notion Property Type |
|----------|--------|-------------------------------|
| Client CRM Tracker | Status | Select (options: Lead, Active, On Hold, Closed - Won, Closed - Lost) |
| Client CRM Tracker | Value | Number (format: Dollar) |
| Client CRM Tracker | Last Contact Date | Date |
| Task Dashboard | Priority | Select (options: Low, Medium, High) |
| Task Dashboard | Status | Select (options: Not Started, In Progress, Blocked, Done) |
| Task Dashboard | Due Date | Date |
| Project Tracker | Status | Select (options: Planning, Active, In Progress, On Hold, Completed) |
| Project Tracker | Start Date / Deadline | Date |
| Project Tracker | Budget | Number (format: Dollar) |

To change a property type: click the column header → **Edit property** → select the new type.

## Step 3: Import the Daily Productivity Template

1. Click **Import** again and choose **Markdown & CSV**.
2. Select `daily_productivity_template.md`.
3. Notion will create a page with all headings, checkboxes, and the table pre-formatted.
4. (Optional but recommended) Turn this into a repeatable template:
   - Create a new database called "Daily Journal."
   - Open a blank entry, paste in the contents of the imported template page.
   - Save it as the database's default **Template** (click the dropdown next to "New" → "+ New template").
   - Now every new daily entry starts pre-filled with your planning structure.

## Step 4: Connect the Databases (Optional, Recommended)

1. Open **Task Dashboard** → add a new property → type **Relation** → link it to **Project Tracker**. This lets you tag each task with its project.
2. Open **Project Tracker** → add a new property → type **Rollup** → source it from the Task Dashboard relation → show "Count of tasks" or "Count where Status = Done."
3. Do the same between **Client CRM Tracker** and **Project Tracker** if you want to see which client each project belongs to.

## Step 5: Build Custom Views

For each database, click **+ Add a view** to create:
- A **Board** view grouped by Status (great for Task Dashboard and Project Tracker).
- A **Calendar** view based on Due Date / Deadline.
- A **Filtered Table** view showing only `Status = Active` for a focused daily dashboard.

## Step 6: Arrange Your Home Page

Go back to your "Productivity Pack" home page and arrange the databases using Notion's **Linked Database** feature so you have one central dashboard summarizing CRM, tasks, and projects at a glance.

## Troubleshooting

- **CSV commas inside a field cause misaligned columns:** All example data avoids embedded commas; if you add your own data with commas, wrap the field in quotes.
- **Dates imported as plain text:** Convert to a Date property after import (Notion doesn't auto-detect date columns on CSV import).
- **Want to merge tasks/projects/CRM into a single database instead of three?** You can, but keeping them separate with relations scales better as your data grows.

---
Need more help? Reply to the email you received this pack in.
